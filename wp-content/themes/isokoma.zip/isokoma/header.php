<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package isokoma
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo("charset"); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, maximum-scale=1.0, minimum-scale=1.0, initial-scale=1" />  
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i">
  <script type="text/javascript" src="https://www.youtube.com/player_api"></script>
  <?php wp_head(); ?>


</head>

<body <?php body_class(); ?>>
  <div id="header_info">
    <div class="container">
      <div class="row">
        <div class="col-12 col-sm-6 info-col-l d-none d-sm-flex">
          <div class="txt-blur"><i class="fa fa-phone"></i> 028 6650 5565</div>
          <div><a href="mailto:info@isokoma.vn" target="_top" class="txt-blur"><i class="fa fa-envelope"></i> info@isokoma.vn</a></div>
        </div>
        <div class="col-12 col-sm-6 info-col-r">
          <?php 
            if (is_user_logged_in()) { ?>
                <div class="txt-blur">
                <div class="dropdown language ml-3 pl-3">
                  <a href="#" class="dropdown-toggle txt-blur" data-toggle="dropdown"><?php _e('Xin chào')  ?> 
                  <?php 
                    $user = wp_get_current_user();
                    echo $user->user_login;
                    
                  ?></a>                    
                  <div class="dropdown-menu dropdown-menu-right" >
                  <a class="dropdown-item" href="/my-account">Thông tin</a>
                  <a class="dropdown-item" href="/my-account/orders">Lịch sử mua hàng</a>
                  <a class="dropdown-item" href="/my-account/edit-account/">Đổi mật khẩu</a>                  
                  <a class="dropdown-item" href="/my-account/customer-logout/">Đăng xuất</a>    
                  </div>
                  </div>
                </div>
            <?php } else { ?>
              <div class="txt-blur">
                <a href="<?php  echo site_url('/my-account'); ?>" class="txt-blur">Đăng nhập</a> hoặc <a class="txt-blur" href="<?php  echo site_url('/register'); ?>">Tạo tài khoản</a>
              </div>
            <?php } ?>
          <div class="dropdown language ml-3 pl-3 border-left">
            <a href="#" class="dropdown-toggle txt-blur" data-toggle="dropdown">Ngôn ngữ</a>
            <div class="dropdown-menu dropdown-menu-right">
              <a class="dropdown-item" href="#">Tiếng Việt</a>
              <a class="dropdown-item" href="#">Tiếng Anh</a>
            </div>
            
            <?php 
            //   pll_the_languages( array( 
            //     'show_flags' => 1,
            //     'show_names' => 0            
            //  ));
            ?>  
            
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="header_logo" class="container">
    <div class="row">
      <div class="col-12 col-sm-4 logo-col-l  d-sm-flex">      
        <div class="ml-3"><a href="https://www.facebook.com/IsokomaVN/" class="txt-blur" target="_blank">
        <i class="fab fa-facebook-f"></i> </a></div>
        
        <!--<div><a href="#" class="txt-blur"><i class="fab fa-twitter"></i></a></div>
			<div><a href="#" class="txt-blur"><i class="fab fa-instagram"></i></a></div>-->
        <div class="ml-3"><a href="https://www.youtube.com/channel/UCFsVNsTri4jKd2AO9Q8mItw" class="txt-blur">
        <i class="fab fa-youtube"></i> </a></div>
        <!--<div><a href="#" class="txt-blur"><i class="fab fa-pinterest"></i></a></div>-->
      </div>
      <div class="col-12 col-sm-4 text-center logo-col-c d-none d-sm-block">
        <a href="<?php echo home_url(); ?>" class="navbar-brand">       
        <img src="<?php echo get_stylesheet_directory_uri()   ?>/logo.png" border="0" alt="Tiger Toyz" title="" />
        </a>
      </div>
      <div class="col-12 col-sm-4 logo-col-r d-none d-sm-flex">	
        <?php get_search_form( ); ?> 
       
        <div class="ml-3">
          <a href="#" class="txt-blur">
          <i class="fa fa-heart" aria-hidden="true"></i>
          </a>
        </div>
        <div class="ml-3">
          <a href="/cart" class="txt-blur">
          <i class="fa fa-shopping-basket" aria-hidden="true"></i>
          </a>
        </div>        
      </div>
    </div>
    <div class="hr-line"></div>
  </div>
  <?php do_action( 'woocommerce_after_cart_table' ); ?>

  <nav id="header_menu" class="navbar navbar-expand-sm navbar-light sticky-top">    
    <a  class="navbar-brand d-sm-none" href="<?php echo home_url(); ?>" class="navbar-brand">
      <img src="<?php echo get_stylesheet_directory_uri()   ?>/logo.png" border="0" alt="Tiger Toyz" title="" />
    </a>       
    <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#collapsible_navbar" aria-expanded="false">
		  <span class="navbar-toggler-icon"></span>
	  </button>
      <?php 
        wp_nav_menu( array(
          'theme_location'  => 'top-nav',
          'depth'           =>  2, // 1 = no dropdowns, 2 = with dropdowns.
          'container'       => 'div',
          'container_class' => 'navbar-collapse collapse',
          'menu_id' => 'navbarIsokomaContent',
          'container_id'    => 'collapsible_navbar',
          'menu_class'      => 'navbar-nav',
          'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
          'walker'          => new WP_Bootstrap_Navwalker(),
      ) );
      ?>    

      
  </nav>

<?php  
  if ( is_front_page() ) : 
    do_action( 'isokoma_slider' );
  endif;
?>

<div id="content" class="site-content" tabindex="-1">
		<div class="content-inner">

