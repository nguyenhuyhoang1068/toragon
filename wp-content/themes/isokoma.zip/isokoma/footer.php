<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package isokoma
 */
?>
  </div><!-- .container -->
</div><!-- #content -->
<?php wp_footer() ?>
<div id="footer_content" class="container">
  <div class="container">
    <div class="row">
      <div class="col-12 col-sm-3">
        <h3>Danh mục</h3>
        <ul>
          <li><a href="/product-category/arttoys" class="txt-blur"></span> Toys</a></li>
          <li><a href="/product-category/tranh" class="txt-blur"></span> Tranh</a></li>
          <li><a href="/product-category/hang-gia-dung" class="txt-blur"></span> Thời trang</a></li>
          <li><a href="/product-category/thoi-trang" class="txt-blur"></span> Đồ điện tử</a></li>
          <li><a href="/product-category/do-dien-tu" class="txt-blur"></span> Hàng gia dụng</a></li>
        </ul>
      </div>
      <div class="col-12 col-sm-3">
        <h3>Thông tin</h3>
        <ul>
          <li><a href="/gioi-thieu/" class="txt-blur"></span> Giới thiệu</a></li>
          <li><a href="/lien-he/" class="txt-blur"></span> Liên hệ</a></li>
          <li><a href="#" class="txt-blur"></span> Điều khoản và điều kiện</a></li>
          <li><a href="#" class="txt-blur"></span> Chính sách bảo mật</a></li>
          <li><a href="#" class="txt-blur"></span> Dịch vụ khách hàng</a></li>
          <li><a href="#" class="txt-blur"></span> Câu hỏi thường gặp</a></li>
        </ul>
      </div>
      <div class="col-12 col-sm-3">
        <h3>Tài khoản</h3>
        <ul>
          <li><a href="/my-account" class="txt-blur"></span> Tài khoản của tôi</a></li>
          <li><a href="#" class="txt-blur"></span> Theo dõi đơn hàng</a></li>
          <li><a href="#" class="txt-blur"></span> Danh sách yêu thích</a></li>
          <li><a href="#" class="txt-blur"></span> Giỏ hàng</a></li>
          <li><a href="#" class="txt-blur"></span> Thanh toán</a></li>
        </ul>
      </div>
      <div class="col-12 col-sm-3">
        <h3>Đăng kí nhận tin</h3>
        <p class="txt-blur">Đăng ký ngay để nhận được thông tin khuyến mãi mới nhất</p>
        <div class="input-group">
          <input type="email" class="form-control txt-email-subscribe" placeholder="Email của bạn">
          <div class="input-group-append">
            <button class="btn btn-subscribe" type="button"><i class="fa fa-angle-right" aria-hidden="true"></i></button>
          </div>
        </div>
        <div class="follow-us">	
          <h3>Follow us</h3>
          <a href="https://www.facebook.com/IsokomaVN/" target="_blank" rel="noopener"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
          <a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a>
          <a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a>
          <a href="#"><i class="fab fa-youtube" aria-hidden="true"></i></a>
          <a href="#"><i class="fab fa-pinterest" aria-hidden="true"></i></a>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="footer_rights" class="container text-center txt-blur"><a href="index.php"><b>© Isokoma VN </b></a> - All rights Reserved</div>




</body>
</html>