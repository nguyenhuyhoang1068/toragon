jQuery('iframe[src*="https://www.youtube.com/embed/"]').addClass("youtube-iframe");
jQuery(".carousel-control-next").click(function() {
  // changes the iframe src to prevent playback or stop the video playback in our case
  jQuery('.mobile .youtube-iframe').each(function(index) {
    jQuery(this).attr('src', jQuery(this).attr('src'));
    return false;
  });
  jQuery('.deskstop .youtube-iframe').each(function(index) {
    jQuery(this).attr('src', jQuery(this).attr('src'));
    return false;
  });

});


jQuery(".carousel-control-prev").click(function() {
  // changes the iframe src to prevent playback or stop the video playback in our case
  jQuery('.mobile .youtube-iframe').each(function(index) {
    jQuery(this).attr('src', jQuery(this).attr('src'));
    return false;
  });
  jQuery('.deskstop .youtube-iframe').each(function(index) {
    jQuery(this).attr('src', jQuery(this).attr('src'));
    return false;
  });

});


jQuery(".carousel-indicators li").click(function() {
  // changes the iframe src to prevent playback or stop the video playback in our case
  jQuery('.mobile .youtube-iframe').each(function(index) {
    jQuery(this).attr('src', jQuery(this).attr('src'));
    return false;
  });
  jQuery('.deskstop .youtube-iframe').each(function(index) {
    jQuery(this).attr('src', jQuery(this).attr('src'));
    return false;
  });

});
jQuery(".carousel-control-prev").click(function(event){  
  jQuery('video').trigger('play');
  jQuery('video').trigger('pause');
});
jQuery(".carousel-control-next").click(function(event){  
  jQuery('video').trigger('play');
  jQuery('video').trigger('pause');
});
jQuery('.carousel-indicators li').click(function (e) { 
  e.preventDefault();  
  jQuery('video').trigger('play');
  jQuery('video').trigger('pause');
});

/*

jQuery('.carousel-control-next').click(function (e) { 
  e.preventDefault();
  
  var player;
  player = new YT.Player('player');
  player.stopVideo();  
});

jQuery('.carousel-control-prev').click(function (e) { 
  e.preventDefault();
  var player;
  player = new YT.Player('player');
  // var videoURL = $('#player').prop('src');
  // videoURL += "&autoplay=1";
  // $('#player').prop('src',videoURL);  
  var videoURL = jQuery('#player').prop('src');
  videoURL = videoURL.replace("&autoplay=1", "");
  jQuery('#player').prop('src','');
  jQuery('#player').prop('src',videoURL);
});


jQuery('.carousel-indicators li').click(function (e) { 
  e.preventDefault();
  var player;
  player = new YT.Player('player');
  // var videoURL = $('#player').prop('src');
  // videoURL += "&autoplay=1";
  // $('#player').prop('src',videoURL);  
  var videoURL = jQuery('#player').prop('src');
  videoURL = videoURL.replace("&autoplay=1", "");
  jQuery('#player').prop('src','');
  jQuery('#player').prop('src',videoURL);
});
*/