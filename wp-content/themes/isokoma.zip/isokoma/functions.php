<?php


add_action('wp_enqueue_scripts',  'isokoma_scripts');
function isokoma_scripts() {
	wp_enqueue_style('isokoma-bootstrap-css', get_stylesheet_directory_uri() . '/libs/bootstrap/css/bootstrap.min.css', array(), '');  
	wp_enqueue_style('isokoma-full-style', get_stylesheet_directory_uri() . '/style.css'); 
	//wp_enqueue_style("isokoma-style", get_stylesheet_directory_uri() . "/css/style.css", array(), '');
	wp_enqueue_style("responsive", get_stylesheet_directory_uri() . "/css/responsive.css",  array(), '');
	wp_enqueue_style("isokoma", get_stylesheet_directory_uri() . "/css/isokoma.css",  array(), '');
	wp_enqueue_style("isokoma-awesome", get_stylesheet_directory_uri() . "/css/font-awesome.min.css",  array(), '');  
  //wp_enqueue_style("isokoma-icons", get_stylesheet_directory_uri() . "/css/icons.css",  array(), '');  
	wp_enqueue_style( 'isokoma-flexslider-css', get_stylesheet_directory_uri() . '/css/flexslider.min.css', array(), '' );   
  wp_enqueue_style( 'isokoma-validate-css', get_stylesheet_directory_uri() . '/css/site-demos.css', array(), '' );   
  
  
  wp_enqueue_script('proper-js', get_stylesheet_directory_uri() . '/js/popper.min.js', array(), '', true);
	wp_enqueue_script('bootstrap-js', get_stylesheet_directory_uri() . '/libs/bootstrap/js/bootstrap.min.js', array(), '', true);  
	wp_enqueue_script( 'isokoma-flexslider-js', get_stylesheet_directory_uri() . '/js/jquery.flexslider-min.js', array(), '', true );
	wp_enqueue_script( 'isokoma-slider-js', get_stylesheet_directory_uri() . '/js/slider-setup.js', array(), '', true );      
	wp_enqueue_script( 'isokoma-fontawesome-js', get_stylesheet_directory_uri() . '/js/fontawesome.js', array(), '', true );      
  wp_enqueue_script( 'isokoma-validate-js', get_stylesheet_directory_uri() . '/js/jquery.validate.min.js', array(), '', true );      
  wp_enqueue_script( 'isokoma-additional-js', get_stylesheet_directory_uri() . '/js/additional-methods.min.js', array(), '', true );  
  wp_enqueue_script( 'isokoma-video-js', get_stylesheet_directory_uri() . '/js/script.js', array(), '', true );    

  
	if(is_singular() && comments_open() && get_option("thread_comments")){
		wp_enqueue_script("comment-reply");
	}
}

function add_favicon() {
  echo '<link rel="shortcut icon" type="image/png" href="' . get_stylesheet_directory_uri() . '/images/favicon.ico" />';
}
add_action('wp_head', 'add_favicon');

// if ( $GLOBALS['pagenow'] === 'wp-login.php' && ! empty( $_REQUEST['action'] ) && $_REQUEST['action'] === 'login' ) {
//   wp_redirect( "/dang-nhap", 301 );
//   exit();      
// }    

/**Woocommerce Include*/
require get_stylesheet_directory() . '/inc/hyperlink-meta.php';
require 'inc/isokoma-functions.php';
require 'inc/isokoma-template-functions.php';
require 'inc/isokoma-template-hooks.php';
require 'inc/woocommerce.php';



if ( ! file_exists( get_stylesheet_directory() . '/inc/class-wp-bootstrap-navwalker.php' ) ) {  
  return new WP_Error( 'class-wp-bootstrap-navwalker-missing', __( 'It appears the class-wp-bootstrap-navwalker.php file may be missing.', 'wp-bootstrap-navwalker' ) );
} else {  
  require_once get_stylesheet_directory() . '/inc/class-wp-bootstrap-navwalker.php';
}


// This theme uses wp_nav_menu() in one location.
register_nav_menus( array(
  'top-nav' => esc_html__('Main Menu', 'isokoma'),      
  'brandtoys-nav' => 'Brand Toys Nav',
  'brandtranh-nav' => 'Brand Tranh Nav',
  'brandhanggiadung-nav' => 'Brand Hanggiadung Nav',
  'brandfashion-nav' => 'Brand Fashion Nav',
  'brandelectronic-nav' => 'Brand Electronic Nav',
) );
add_theme_support( 'menus' );


// function add_menuclass($ulclass) {
//   return preg_replace('/<a /', '<a class="list-group-item list-group-item-action"', $ulclass);
// }
// add_filter('wp_nav_menu','add_menuclass');

// add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);
// function special_nav_class ($classes, $item) {   
//   global $wp;	
// 	$current_url = home_url( add_query_arg( array(), $wp->request ) ); 						
// 	$url_array = explode('/',$current_url); 
//   if ((in_array('brand', $url_array))  && (in_array('bearbrick', $url_array))   && (in_array('70', $url_array)) ){
//     $classes[] = 'fas fa-caret-right';  
//   }
//   if ((in_array('brand', $url_array))  && (in_array('bearbrick', $url_array))   && (in_array('100', $url_array)) ){
//     $classes[] = 'fas fa-caret-right';  
//   }
//   return $classes;
// }



add_action( 'after_setup_theme', 'isokoma_language_theme_setup' );
function isokoma_language_theme_setup(){
  load_theme_textdomain( 'isokoma', get_template_directory() . '/languages' );
}


/**
 * Custom field Pre Order 
 * 
 * 
 * */
/*
function cfwc_create_custom_field() {
  $args = array(
  'id' => 'custom_text_field_pre_order',
  'label' => __( 'Remark', 'isokoma' ),
  'class' => 'cfwc-custom-field',
  'desc_tip' => true,
  'description' => __( 'Enter the pre-order.', 'ctwc' ),
  );
  woocommerce_wp_text_input( $args );
 }
 add_action( 'woocommerce_product_options_general_product_data', 'cfwc_create_custom_field' );

 function cfwc_save_custom_field( $post_id ) {
  $product = wc_get_product( $post_id );
  $title = isset( $_POST['custom_text_field_pre_order'] ) ? $_POST['custom_text_field_pre_order'] : '';
  $product->update_meta_data( 'custom_text_field_pre_order', sanitize_text_field( $title ) );
  $product->save();
 }
 add_action( 'woocommerce_process_product_meta', 'cfwc_save_custom_field' );
*/
 
function cfwc_create_size_custom_field() {
  $args = array(
  'id' => 'custom_text_field_size',
  'label' => __( 'The size', 'isokoma' ),
  'class' => 'cfwc-custom-field',
  'desc_tip' => true,
  'description' => __( 'Enter the Size.', 'ctwc' ),
  );
  woocommerce_wp_text_input( $args );
 }
 add_action( 'woocommerce_product_options_general_product_data', 'cfwc_create_size_custom_field' );

 function cfwc_save_size_custom_field( $post_id ) {
  $product = wc_get_product( $post_id );
  $title = isset( $_POST['custom_text_field_size'] ) ? $_POST['custom_text_field_size'] : '';
  $product->update_meta_data( 'custom_text_field_size', sanitize_text_field( $title ) );
  $product->save();
 }
 add_action( 'woocommerce_process_product_meta', 'cfwc_save_size_custom_field' );

/**
  * Breadcrumb
  */

add_filter( 'woocommerce_breadcrumb_defaults', 'wcc_change_breadcrumb_delimiter' );
function wcc_change_breadcrumb_delimiter( $defaults ) {
	// Change the breadcrumb delimeter from '/' to '>'
	$defaults['delimiter'] = ' &gt; ';
	return $defaults;
}


/**
  * Woocommerce
  */
//remove_action( 'woocommerce_product_thumbnails', 'woocommerce_show_product_thumbnails', 20 );
//remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );

  
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
//remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );
//remove_action( 'woocommerce_before_shop_loop', 'storefront_woocommerce_pagination', 30 );
remove_action( 'woocommerce_before_shop_loop', 'storefront_woocommerce_pagination', 30 );
remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );

// add_filter( 'loop_shop_per_page', 'new_loop_shop_per_page', 20 );
// function new_loop_shop_per_page( $cols ) {
//   // $cols contains the current number of products per page based on the
//   //value stored on Options -> Reading
//   // Return the number of products you wanna show per page.
//   $cols = 90;
//   return $cols;
// }


// function tp_homepage_blocks() { 
//  remove_action( 'homepage', 'storefront_featured_products', 40 );
//  remove_action( 'homepage', 'storefront_popular_products', 50 );
// }
// add_action( 'after_setup_theme', 'tp_homepage_blocks', 10 );

// add_action( 'init', 'bbloomer_hide_price_add_cart_not_logged_in' );  
// function bbloomer_hide_price_add_cart_not_logged_in() {   
//    if ( ! is_user_logged_in() ) {      
//       remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
//       remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
//       remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
//       remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );   
//       //add_action( 'woocommerce_single_product_summary', 'bbloomer_print_login_to_see', 31 );
//       //add_action( 'woocommerce_after_shop_loop_item', 'bbloomer_print_login_to_see', 11 );
//    }
// }
  
// function bbloomer_print_login_to_see() {
//    echo '<a href="' . get_permalink(wc_get_page_id('myaccount')) . '">' . __('Login to see prices', 'theme_name') . '</a>';
// }

// add_action( 'init', 'isokoma_remove_default_sorting_storefront' );
// function isokoma_remove_default_sorting_storefront() {
//    remove_action( 'woocommerce_after_shop_loop', 'woocommerce_catalog_ordering', 10 );
//    remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 10 );
// }

/**
 * Change number of related products output
 */ 
function woo_related_products_limit() {
  global $product;	
	$args['posts_per_page'] = 4;
	return $args;
}
add_filter( 'woocommerce_output_related_products_args', 'isokoma_related_products_args', 20 );
  function isokoma_related_products_args( $args ) {
	$args['posts_per_page'] = 4; // 4 related products
	$args['columns'] = 4; // arranged in 2 columns
	return $args;
}
//add_filter( 'wc_product_sku_enabled', '__return_false' );
// add_action( 'woocommerce_single_product_summary', 'isokoma_designs_show_sku', 5 );
// function isokoma_designs_show_sku(){
//     global $product;
//     echo 'SKU: ' . $product->get_sku();
// }


// function sv_remove_product_page_skus( $enabled ) {
//   if ( ! is_admin() && is_product() ) {
//       return false;
//   }

//   return $enabled;
// }
// add_filter( 'wc_product_sku_enabled', 'sv_remove_product_page_skus' );

// add_filter( 'posts_request', 'dump_request' );
// function dump_request( $input ) {
//     var_dump($input);
//     return $input;
// }

// function SearchFilter($query) {
//   if ($query->is_search) {
//     $meta_query_args = array(
//       'relation' => 'OR',
//       array(
//         'key' => '_sku',
//         'value' => $query->query_vars['s'],
//         'compare' => '=',
//       )
//     );    
//     $query->set('meta_query', $meta_query_args);
//   }  
//   return $query;
// }
// add_filter('pre_get_posts','SearchFilter');


add_filter( 'woocommerce_single_product_carousel_options', 'customslug_single_product_carousel_options', 99, 1 );
function customslug_single_product_carousel_options( $options ) {
    $options['animation'] = 'fade';
    $options['animationSpeed'] = 400;
    return $options;
}

/* Add sku to product search */

function isokoma_pre_get_posts( $query ) {  
  if ( is_admin() || ! $query->is_main_query() || ! $query->is_search()){
    return;
  }  
  add_filter('posts_join', 'isokoma_search_join' );
  add_filter('posts_where', 'isokoma_search_where' );
  add_filter('posts_groupby', 'isokoma_search_groupby' );  
  }
  add_action( 'pre_get_posts', 'isokoma_pre_get_posts' );
  
  function isokoma_search_join( $join ){
     global $wpdb;     
     $join .= " LEFT JOIN $wpdb->postmeta gm ON (" . 
     $wpdb->posts . ".ID = gm.post_id AND gm.meta_key='_sku')"; // change to your meta key if not woo  
     return $join;
  }
  
  function isokoma_search_where( $where ){
     global $wpdb;
     $where = preg_replace(
       "/\(\s*{$wpdb->posts}.post_title\s+LIKE\s*(\'[^\']+\')\s*\)/",
       "({$wpdb->posts}.post_title LIKE $1) OR (gm.meta_value LIKE $1)", $where );
     return $where;
  }
  /* grouping by id to make sure no dupes */
  function isokoma_search_groupby( $groupby ){
     global $wpdb;
     $mygroupby = "{$wpdb->posts}.ID";
     if( preg_match( "/$mygroupby/", $groupby )) {
       // grouping we need is already there
       return $groupby;
     }
     if( !strlen(trim($groupby))) {
        // groupby was empty, use ours
        return $mygroupby;
     }
     // wasn't empty, append ours
     return $groupby . ", " . $mygroupby;
  }


/*
* List viewed Product
*/
/*
function viewedProduct () {
  global $post;
  session_start();
  if (!isset($_SESSION["viewed"])) {
    $_SESSION["viewed"] = array();
  }
  if (is_singular('product')) {
    $_SESSION["viewed"][get_the_ID()] = get_the_ID();
  }  
}
add_action('template_redirect', 'viewedProduct');
*/

function custom_track_product_view() {
  if ( ! is_singular( 'product' ) ) {
      return;
  }
  global $post;
  if ( empty( $_COOKIE['woocommerce_recently_viewed'] ) )
      $viewed_products = array();
  else
      $viewed_products = (array) explode( '|', $_COOKIE['woocommerce_recently_viewed'] );

  if ( ! in_array( $post->ID, $viewed_products ) ) {
      $viewed_products[] = $post->ID;
  }

  if ( sizeof( $viewed_products ) > 15 ) {
      array_shift( $viewed_products );
  }
  wc_setcookie( 'woocommerce_recently_viewed', implode( '|', $viewed_products ) );
}
add_action( 'template_redirect', 'custom_track_product_view', 20 );

function isokoma_woocommerce_recently_viewed_products( $atts, $content = null ) {
  // Get shortcode parameters
  extract(shortcode_atts(array(
      "per_page" => '12'
  ), $atts));
  // Get WooCommerce Global
  global $woocommerce;
  // Get recently viewed product cookies data
  $viewed_products = ! empty( $_COOKIE['woocommerce_recently_viewed'] ) ? (array) explode( '|', $_COOKIE['woocommerce_recently_viewed'] ) : array();
  $viewed_products = array_filter( array_map( 'absint', $viewed_products ) );
  // If no data, quit
  if ( empty( $viewed_products ) )
      return __( 'Chưa có sản phẩm đã xem', 'isokoma' );
  // Create the object
  ob_start();
  // Get products per page
  if( !isset( $per_page ) ? $number = 12 : $number = $per_page )
  // Create query arguments array
  $query_args = array(
                  'posts_per_page' => $number, 
                  'no_found_rows'  => 1, 
                  'post_status'    => 'publish', 
                  'post_type'      => 'product', 
                  'post__in'       => $viewed_products, 
                  'orderby'        => 'rand'
                  );
  // Add meta_query to query args
  $query_args['meta_query'] = array();
  // Check products stock status
  $query_args['meta_query'][] = $woocommerce->query->stock_status_meta_query();
  // Create a new query
  $get_product = new WP_Query($query_args);
  // If query return results
  $content = "";
  if ( $get_product->have_posts() ) {    
    // Start the loop
    while ( $get_product->have_posts()) {
      $get_product->the_post();
      global $product;
      $content .= '<div class="item-viewed-product">';
      $content .= '<a href="'. get_permalink().'" >';          
      $content .= get_the_post_thumbnail($get_product->post->ID, 'isokoma-banner-500', array('class'=>'thumbnail'));          
      $content .= '</a>';
      $content .= '<h3><a href="'. get_permalink().'">';
      $content .=   get_the_title(); 
      $content .= '</a> </h3>';
      $content .= '<div class="product-price">'. $product->get_price_html().'</div>';
      //$content .= '<a href="'. bloginfo('url').'"add-to-cart="'. the_ID().'"><i class="fas fa-shopping-basket" aria-hidden="true"></i> Cart</a>';          
      $content .= '</div>';
    }      
  }
  // Get clean object
  $content .= ob_get_clean();
  // Return whole content
  return $content;
}




// Register the shortcode
add_shortcode("woocommerce_recently_viewed_products", "isokoma_woocommerce_recently_viewed_products");


/*
add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
add_filter( 'woocommerce_loop_add_to_cart_link', 'quantity_inputs_for_woocommerce_loop_add_to_cart_link', 10, 2 );
function quantity_inputs_for_woocommerce_loop_add_to_cart_link( $html, $product ) {
	//if ( is_user_logged_in() && is_shop() || is_product_category() && $product && $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() && ! $product->is_sold_individually() ) {
  if ($product && is_user_logged_in()) {
		$html = '<form action="' . esc_url( $product->add_to_cart_url() ) . '" class="cart" method="post" enctype="multipart/form-data">';
		$html .= woocommerce_quantity_input( array(), $product, false );
		$html .= '<button type="submit" class="button alt">' . esc_html( $product->add_to_cart_text() ) . '</button>';
		$html .= '</form>';
	}
	return $html;
}
*/
/*
// Sort by sale
add_filter( 'woocommerce_get_catalog_ordering_args', 'isokoma_sale_get_catalog_ordering_args' );
function isokoma_sale_get_catalog_ordering_args( $args ) {
    //$orderby_value = isset( $_GET['orderby'] ) ? woocommerce_clean( $_GET['orderby'] ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );
    if ( isset( $_GET['orderby'] ) && ! empty( $_GET['orderby'] ) ) {      
      if ( 'on_sale' == wc_clean( wp_unslash( $_GET['orderby'] ) ) ) {
        $args['orderby'] = 'meta_value_num';
        $args['order'] = 'DESC';
        $args['meta_key'] = '_sale_price'; 
      }
    }     
    
    return $args;
}

 
add_filter( 'woocommerce_default_catalog_orderby_options', 'isokoma_sale_catalog_orderby' );
add_filter( 'woocommerce_catalog_orderby', 'isokoma_sale_catalog_orderby' );
function isokoma_sale_catalog_orderby( $sortby ) {
    $sortby['on_sale'] = 'Sort by on sale';
    return $sortby;
}

//Sort by quantity
add_filter( 'woocommerce_get_catalog_ordering_args', 'isokoma_quantity_get_catalog_ordering_args' );
function isokoma_quantity_get_catalog_ordering_args( $args ) {
    //$orderby_value = isset( $_GET['orderby'] ) ? woocommerce_clean( $_GET['orderby'] ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );
    if ( isset( $_GET['orderby'] ) && ! empty( $_GET['orderby'] ) ) {      
      if ( 'availability' == wc_clean( wp_unslash( $_GET['orderby'] ) ) ) {
        $args['orderby'] = 'meta_value_num';
        $args['order'] = 'DESC';
        $args['meta_key'] = '_stock'; 
      }
    }     
    
    return $args;
}

 
add_filter( 'woocommerce_default_catalog_orderby_options', 'isokoma_quantity_catalog_orderby' );
add_filter( 'woocommerce_catalog_orderby', 'isokoma_quantity_catalog_orderby' );
function isokoma_quantity_catalog_orderby( $sortby ) {
    $sortby['availability'] = 'Sort by on quantity';
    return $sortby;
}

//Sort by SKU
add_filter( 'woocommerce_get_catalog_ordering_args', 'isokoma_stock_get_catalog_ordering_args' );
function isokoma_stock_get_catalog_ordering_args( $args ) {
    //$orderby_value = isset( $_GET['orderby'] ) ? woocommerce_clean( $_GET['orderby'] ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );
    if ( isset( $_GET['orderby'] ) && ! empty( $_GET['orderby'] ) ) {      
      if ( 'sku' == wc_clean( wp_unslash( $_GET['orderby'] ) ) ) {
        $args['orderby'] = 'meta_value';
        $args['order'] = 'DESC';
        $args['meta_key'] = '_sku'; 
      }
    }
    
    return $args;
}
 
add_filter( 'woocommerce_default_catalog_orderby_options', 'isokoma_stock_catalog_orderby' );
add_filter( 'woocommerce_catalog_orderby', 'isokoma_stock_catalog_orderby' );
function isokoma_stock_catalog_orderby( $sortby ) {
    $sortby['sku'] = 'Sort by on SKU';
    return $sortby;
}
*/

/**
 * List of perchased products 
 */
add_filter ( 'woocommerce_account_menu_items', 'isokoma_purchased_products_link', 40 );
add_action( 'init', 'isokoma_add_products_endpoint' );
add_action( 'woocommerce_account_purchased-products_endpoint', 'isokoma_populate_products_page' );
 
// here we hook the My Account menu links and add our custom one
function isokoma_purchased_products_link( $menu_links ){

	return array_slice( $menu_links, 0, 2, true )
	+ array( 'purchased-products' => 'Purchased Products' )
	+ array_slice( $menu_links, 2, NULL, true );
 
}
 
// here we register our rewrite rule
function isokoma_add_products_endpoint() {
	add_rewrite_endpoint( 'purchased-products', EP_ALL );
  flush_rewrite_rules();
}
 
// here we populate the new page with the content
function isokoma_populate_products_page() {
/*
   // Get the current user Object 
   $current_user = wp_get_current_user();
   // Check if the user is valid 
   if ( 0 == $current_user->ID ) return;
   $args = array(
     'numberposts' => -1,
     'meta_key' => '_customer_user',
     'meta_value' => $current_user->ID,
     'post_type' => wc_get_order_types(),
     'post_status' => array_keys( wc_get_is_paid_statuses() ),
   );
   $customer_orders = get_posts( $args);
   // loop through the orders and return the IDs 
   if ( ! $customer_orders ) return;
   $product_ids = array();
   foreach ( $customer_orders as $customer_order ) {
     $order = wc_get_order( $customer_order->ID );
     $items = $order->get_items();
     foreach ( $items as $item ) {
       $product_id = $item->get_product_id();
       $product_ids[] = $product_id;
     }
   }		
   var_dump($product_ids);
   return $product_ids;
*/
 
	global $wpdb;
 
	// this SQL query allows to get all the products purchased by the current user
	// in this example we sort products by date but you can reorder them another way
	$purchased_products_ids = $wpdb->get_col( $wpdb->prepare(
		"
		SELECT      itemmeta.meta_value
		FROM        " . $wpdb->prefix . "woocommerce_order_itemmeta itemmeta
		INNER JOIN  " . $wpdb->prefix . "woocommerce_order_items items
		            ON itemmeta.order_item_id = items.order_item_id
		INNER JOIN  $wpdb->posts orders
		            ON orders.ID = items.order_id
		INNER JOIN  $wpdb->postmeta ordermeta
		            ON orders.ID = ordermeta.post_id
		WHERE       itemmeta.meta_key = '_product_id'
		            AND ordermeta.meta_key = '_customer_user'
		            AND ordermeta.meta_value = %s
		ORDER BY    orders.post_date DESC
		",
		get_current_user_id()
	) );
  
	// some orders may contain the same product, but we do not need it twice
	$purchased_products_ids = array_unique( $purchased_products_ids );
 
	// if the customer purchased something
	if( !empty( $purchased_products_ids ) ) :
 
		// it is time for a regular WP_Query
		$purchased_products = new WP_Query( array(
			'post_type' => 'product',
			'post_status' => 'publish',
			'post__in' => $purchased_products_ids,
			'orderby' => 'post__in'
		) );
 
		echo '<div class="woocommerce columns-3">';
 
		woocommerce_product_loop_start();
 
		while ( $purchased_products->have_posts() ) : $purchased_products->the_post();
    
			wc_get_template_part( 'content', 'product' );
 
		endwhile;
 
		woocommerce_product_loop_end();
 
		//woocommerce_reset_loop();
		wp_reset_postdata();
 
		echo '</div>';
	else:
		echo 'Nothing purchased yet.';
	endif;

}

/**
 * Change the text Add to cart to Cart
 *
// To change add to cart text on single product page
add_filter( 'woocommerce_product_single_add_to_cart_text', 'woocommerce_custom_single_add_to_cart_text' ); 
function woocommerce_custom_single_add_to_cart_text() {
    return __( 'Cart', 'isokoma' ); 
}

// To change add to cart text on product archives(Collection) page
add_filter( 'woocommerce_product_add_to_cart_text', 'woocommerce_custom_product_add_to_cart_text' );  
function woocommerce_custom_product_add_to_cart_text() {
    return __( 'Cart', 'isokoma' );
}
*/
/*
add_filter('woocommerce_get_availability_text', 'themeprefix_change_soldout', 10, 2 );
function themeprefix_change_soldout ( $text, $product) {
  if ( !$product->is_in_stock() ) {
    $text = '<div class="">Sold out.</div>';
  }
  return $text;
}

function sww_wc_remove_variation_stock_display( $data ) {
  unset( $data['availability_html'] );
  return $data;
}
add_filter( 'woocommerce_available_variation', 'sww_wc_remove_variation_stock_display', 99 );
*/

/**
 * Remove stock to empty in product teaser
 */
add_filter( 'woocommerce_get_stock_html', '__return_empty_string' );

/**
 * Remove sort popularity
 */
function my_woocommerce_catalog_orderby( $orderby ) {
  unset($orderby["popularity"]);  
  return $orderby;
}
add_filter( "woocommerce_catalog_orderby", "my_woocommerce_catalog_orderby", 20 );
